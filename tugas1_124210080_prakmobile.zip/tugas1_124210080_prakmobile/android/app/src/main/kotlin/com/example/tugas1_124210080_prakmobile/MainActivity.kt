package com.example.tugas1_124210080_prakmobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
